#ifndef PLAYERCONTROLS_H
#define PLAYERCONTROLS_H

#include <QWidget>
#include <QBoxLayout>
#include <QMediaPlayer>
#include <QStyle>
#include <QTimer>
#include <QMenu>
#include "durationslider.h"
#include "fullscreenplayercontrols.h"
#include "qss.h"
QT_BEGIN_NAMESPACE
class QToolButton;
class QSlider;
class QComboBox;
class QPushButton;
class QLabel;
QT_END_NAMESPACE

class PlayerControls : public QWidget
{
    Q_OBJECT

public:
    explicit PlayerControls(QWidget *parent = nullptr);
    void playStatus_clicked();
    void setFullScreen(bool value);
    QLabel* duration_label = nullptr;
    DurationSlider* duration_slider = nullptr;
    //框架
    QVBoxLayout *main_layout = nullptr; //主框架
    QHBoxLayout *wave_layout=nullptr;//放波形图
    QHBoxLayout *progressBar_layout = nullptr;  // 放进度条
    QHBoxLayout *control_layout = nullptr;  //放按钮等控件
    QHBoxLayout *left_layout = nullptr;
    QHBoxLayout *center_layout = nullptr;
    QHBoxLayout *right_layout = nullptr;
signals:
    void changeMediaDirShow_signal(); //改变目录显示状态
    void invert_signal();   //倒放
    void durationStep_signal(int);  //进度变化幅度
    void playMode_signal(int);  //播放模式
    void preOne_signal();   //上一首
    void playStatus_signal();   //播放状态
    void nextOne_signal();  //下一首
    void playSpeed_signal(int); //播放倍速
    void volume_signal(int);    //音量控制
    void volumeGraphy_signal(); //音频波形图
    void fullScreen_signal(bool);    //改变屏幕大小
    void showList_signal(bool); //显示列表

public:
    QToolButton *playStatus_button = nullptr; //控制播放状态
    QToolButton *preOne_button = nullptr; //控制上一首
    QToolButton *nextOne_button = nullptr;    //控制下一首
    QSlider *volume_slider = nullptr;   //音量滑杆
    void setShowListVisable(bool);
    QToolButton *changeMediaDirShow_button = nullptr;   //改变目录显示状态
    QPushButton *invert_button = nullptr;   //倒放控制
    QPushButton *durationStep_bututon = nullptr;    //进度改变幅度
    int durationStep_value = 1; //进度改变幅度
    QToolButton *playMode_button = nullptr; //播放模式控制
    int currentPlayMode = 1;   //当前播放模式
    QPushButton *playSpeed_button = nullptr;    //播放速度控制
    int currentPlaySpeed = 1;   //当前播放倍速
    QToolButton *volume_button = nullptr;   //音量按钮
    bool isMuted = false; //是否静音
    int volume_int = 50; //音量
    QToolButton *volumeGraphy_button = nullptr; //波形图
    QToolButton *fullScreen_button = nullptr;   //改变屏幕大小
    bool isFullScreen = false;  //当前是否为全屏
    QToolButton *showList_button = nullptr; //显示隐藏列表
    bool isShowList = true;
};

#endif // PLAYERCONTROLS_H
